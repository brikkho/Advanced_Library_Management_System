import save_all_books

def lend_books(all_books):
    search_book = input("Enter Book Title to Delete: ")
    for book in all_books:
        if book["title"] == search_book:
            all_books.remove(book)
            save_all_books.save_all_books(all_books)
            print("Book Deleted Successfully\n")
            return all_books
    
    print("Book Not Found")
    
def delete_books(all_books):
    search_book = input("Enter Book Title to Delete: ")
    for book in all_books:
        if book["title"] == search_book:
            all_books.remove(book)
            save_all_books.save_all_books(all_books)
            print("Book Deleted Successfully\n")
            return all_books
    
    print("Book Not Found")
